DECwindows server fonts from OpenVMS VAX V6.2
=============================================

Taken from the DECwindows base support savesets on the OpenVMS VAX V6.2
CD (VAXVMS062-AG-PXKUD-RE), DECW062.E and DECW062.F, directories
[SYS0.SYSFONT.DECW.*]: 75DPI, 100DPI, COMMON, CURSOR16, CURSOR32.  The
files are as VMS stored them, in DECwindows' own compiled .DECW$FONT
format, not yet converted for X.Org.

These fonts are not free software.  DEC's own families (Terminal, Menu,
...) belong to DEC's successors; others (Avant Garde and the other
PostScript faces) were licensed to DEC by their foundries.  Use them with
your own licensed VMS installation.  Check the licences before
distributing them.
